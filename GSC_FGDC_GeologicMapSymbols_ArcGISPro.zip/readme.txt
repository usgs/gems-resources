Readme for GSC_FGDC_GeologicMapSymbols

This file is an ArcGIS Style file that is usable with either ArcMap (.style extension) or ArcGIS Pro (.stylx extension).
It is a combination of two styles; FGDCcymk (polygon fill colors) and FGDC_GSC_20100414 (point, line, and text symbols). 

FGDCcmyk consists of the 1000 colors shown in the FGDC CMYK Color Chart that is included in the FGDC Digital Cartographic Standard for Geologic Map Symbolization (https://ngmdb.usgs.gov/fgdc_gds/geolsymstd.php) and no other symbols. The color symbols are named by the reference number shown in the upper-left of each color box on that plate.

FGDC_GSC_20100414 was developed by Vic Dohar and Dave Everett of the Canadian Geologica Survey, supported through the Geo-mapping for Energy and Minerals Program. It consists of 689 point, 905 line, 280 text, and 19 polygon fill symbols. The developers ask that comments be directed to the FGDC, at mapsymbol@flagmail.wr.usgs.gov.

NOTE: For the marker symbols in these styles to display as intended, the five FGDCGeoSym symbol fonts must be installed. These are available from the USGS GeMS website: https://ngmdb.usgs.gov/Info/standards/GeMS/ or https://github.com/usgs/gems-resources

Evan Thoms, USGS
ethoms@usgs.gov
1/11/20
